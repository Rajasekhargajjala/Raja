
export const Navbar = () => {
  return (
    <div className="navbar">
      <a href="#"> Contact Us </a>
      <a href="#">About Us| </a>
      <a href="#">Home |</a>
    </div>
  );
}
Sidebar.js
export function Sidebar() {
  return (
    <div className="sidebabr">
      <span>
        Category inforamtion
        Sidebar
      </span>
    </div>
  );
}
export default Navbar;